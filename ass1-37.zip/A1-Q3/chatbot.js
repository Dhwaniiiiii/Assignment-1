module.exports.ChatbotReply = function(message)
	{
		this.Bot_Age = 22;
		this.Bot_Name = "name1";
		this.Bot_University = "VNSGU";
		this.Bot_Country = "INDIA";
		
		message= message.toLowerCase()

		if(message.indexOf("hi") > -1 || 
			message.indexOf("hello") > -1 || 
			message.indexOf("welcome") > -1 )
		{
			return "Hi! I'm a chatbot...";
		} 
		else if(message.indexOf("age") > -1 && 
			message.indexOf("your"))
		{
			return "I'm " + this.Bot_Age;
		}
		else if (message.indexOf("how") > -1 && 
			message.indexOf("are") && 
			message.indexOf("you"))
		{
			return "I'm fine ^_^"
		}
		else if(message.indexOf("where") > -1 &&
			 message.indexOf("do") && 
			 message.indexOf("you") && 
			message.indexOf("live"))
		{
			return "I live in " + this.Bot_Country;
		}
		else if(message.indexOf("bye") > -1 || 
			message.indexOf("seeya") > -1 || 
			message.indexOf("welcome") > -1 )
		{
			return "Have a good day. bye...";
		} 
		return "Sorry, I didn't get it :( ";
	}