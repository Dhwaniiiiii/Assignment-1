const mysql = require("mysql");
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: 'employeeeDB'
});
const selectAllEmployees = () => {
    return new Promise((resolve, reject) => {
        con.query("SELECT * FROM employeeTB", (err, result, fields) => {
        if (err)    
        {
            reject(err);
        }
        else 
        {
            resolve(result);
        }
        })
    })
}

con.connect((err) => 
{
if (err) 
{
    console.log("error: " + err)
} 
else 
{
    //inserting record in employee table
    con.query("INSERT INTO employeeTB values(null,'Dhwani Parmar',22,'dp12@gmail.com')", (err, result) => {

if (err) 
{
    console.log("error: " + err)
} 
else 
{
    console.log("record inserted")
}
})
selectAllEmployees().then(result => {
    console.log(result)
}).catch(err => {
    console.log("error: " + err)
})
}
})